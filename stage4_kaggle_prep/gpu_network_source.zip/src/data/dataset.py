"""
PyTorch Dataset and DataLoader Pipeline for Chest X-Ray Classification.

Features:
- Robust ChestXRayDataset loading from prepared split directories or CSV manifests
- Standard CNN / ResNet-18 preprocessing (224x224, ImageNet normalization, zero-dependency transforms)
- Official CXformer-Small transfer learning preprocessing pipeline:
  * 518x518 input resolution with bicubic resize and center crop
  * Official CustomBitImageProcessor with channel-wise histogram equalization (cv2.equalizeHist)
  * Rescaling (1/255) and ImageNet normalization (Mean: [0.485, 0.456, 0.406], Std: [0.229, 0.224, 0.225])
  * Float32 tensor output compatible with Dinov2WithRegistersModel backbone
- Dynamic class weight computation strictly from training labels
- Safe DataLoader factory with Windows-compatible worker configuration
"""

import os
import random
from typing import Dict, List, Optional, Tuple, Callable, Any
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader

# Canonical class-to-index mapping (Alphabetical standard)
CLASS_TO_IDX: Dict[str, int] = {"NORMAL": 0, "PNEUMONIA": 1}
IDX_TO_CLASS: Dict[int, str] = {0: "NORMAL", 1: "PNEUMONIA"}

# ImageNet normalization standards (compatible with ResNet-18 pretrained weights)
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


# ============================================================================
# Transform Pipeline (Supports torchvision with Pure Pillow/Torch Fallback)
# ============================================================================

class PurePythonTransform:
    """
    Pure Python/Pillow/PyTorch image transform callable.
    Guarantees zero-dependency operation when torchvision is not installed.
    """

    def __init__(
        self,
        image_size: int = 224,
        is_training: bool = False,
        mean: List[float] = IMAGENET_MEAN,
        std: List[float] = IMAGENET_STD,
    ):
        self.image_size = image_size
        self.is_training = is_training
        self.mean = torch.tensor(mean, dtype=torch.float32).view(3, 1, 1)
        self.std = torch.tensor(std, dtype=torch.float32).view(3, 1, 1)

    def __call__(self, img: Image.Image) -> torch.Tensor:
        # Convert to RGB (chest X-rays may be grayscale or RGBA)
        if img.mode != "RGB":
            img = img.convert("RGB")

        # Resize
        img = img.resize((self.image_size, self.image_size), Image.Resampling.BILINEAR)

        # Training augmentations
        if self.is_training:
            # Random horizontal flip
            if random.random() < 0.5:
                img = img.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            # Subtle random rotation (-10 to +10 degrees)
            if random.random() < 0.5:
                angle = random.uniform(-10.0, 10.0)
                img = img.rotate(angle, resample=Image.Resampling.BILINEAR)

        # Convert PIL to Tensor: shape (H, W, 3) -> (3, H, W) normalized to [0, 1]
        arr = np.array(img, dtype=np.float32) / 255.0
        tensor = torch.from_numpy(arr).permute(2, 0, 1)

        # Normalize
        tensor = (tensor - self.mean) / self.std
        return tensor


def get_transforms(
    image_size: int = 224,
    is_training: bool = False,
    mean: List[float] = IMAGENET_MEAN,
    std: List[float] = IMAGENET_STD,
) -> Callable:
    """
    Constructs an image preprocessing pipeline.
    Uses torchvision if installed, otherwise uses PurePythonTransform.
    """
    try:
        from torchvision import transforms

        if is_training:
            return transforms.Compose([
                transforms.Lambda(lambda img: img.convert("RGB") if img.mode != "RGB" else img),
                transforms.Resize((image_size, image_size)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomRotation(degrees=10),
                transforms.ToTensor(),
                transforms.Normalize(mean=mean, std=std),
            ])
        else:
            return transforms.Compose([
                transforms.Lambda(lambda img: img.convert("RGB") if img.mode != "RGB" else img),
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize(mean=mean, std=std),
            ])
    except ImportError:
        return PurePythonTransform(
            image_size=image_size,
            is_training=is_training,
            mean=mean,
            std=std,
        )


# ============================================================================
# CXformer-Small Preprocessing Pipeline (Official Custom Processor)
# ============================================================================

def get_cxformer_processor(model_dir: Optional[str] = None):
    """
    Loads and returns the official CXformer-Small image processor
    (CustomBitImageProcessor) from the resolved model directory.

    Verifies that the processor:
      - Has do_hist_equalization=True (histogram equalization enabled)
      - Has target crop_size (518, 518)
      - Uses official ImageNet normalization (mean: [0.485, 0.456, 0.406], std: [0.229, 0.224, 0.225])
    """
    try:
        from transformers import AutoImageProcessor
    except ImportError as e:
        raise ImportError(
            f"Failed to import 'transformers.AutoImageProcessor': {e}. "
            "Please ensure transformers is installed."
        )

    try:
        from src.models.cxformer import resolve_cxformer_dir
        resolved_dir = resolve_cxformer_dir(model_dir)
    except Exception as e:
        raise FileNotFoundError(
            f"Could not resolve CXformer-Small model directory for image processor: {e}"
        )

    try:
        processor = AutoImageProcessor.from_pretrained(resolved_dir, trust_remote_code=True)
    except Exception as e:
        raise RuntimeError(
            f"Failed to load official CXformer processor from '{resolved_dir}': {e}. "
            "Ensure opencv-python (cv2) and transformers are installed."
        )

    return processor


class CXformerTransform:
    """
    Preprocessing callable wrapping the official CXformer-Small processor.

    Preserves the official CXformer-Small preprocessing pipeline:
      1. Converts PIL Image to RGB (chest X-rays may be grayscale or RGBA).
      2. Applies custom histogram equalization (cv2.equalizeHist per channel).
      3. Resizes shortest edge to 518 and center-crops to (518, 518) via Bicubic interpolation.
      4. Rescales pixel values by 1/255 (factor ~0.00392157).
      5. Normalizes with official ImageNet mean [0.485, 0.456, 0.406] and std [0.229, 0.224, 0.225].
      6. Returns a float32 PyTorch tensor of shape (3, 518, 518).
    """

    def __init__(
        self,
        model_dir: Optional[str] = None,
        processor: Optional[Any] = None,
    ):
        if processor is not None:
            self.processor = processor
        else:
            self.processor = get_cxformer_processor(model_dir)

    def __call__(self, img: Image.Image) -> torch.Tensor:
        if img.mode != "RGB":
            img = img.convert("RGB")

        # Process image using official CustomBitImageProcessor
        processed = self.processor(img, return_tensors="pt")

        # Extract pixel_values tensor: shape (1, 3, 518, 518) -> squeeze to (3, 518, 518)
        pixel_values = processed["pixel_values"].squeeze(0)
        return pixel_values.to(dtype=torch.float32)


def get_cxformer_transform(
    model_dir: Optional[str] = None,
    processor: Optional[Any] = None,
) -> Callable:
    """
    Factory helper to construct a CXformerTransform callable.
    """
    return CXformerTransform(model_dir=model_dir, processor=processor)


# ============================================================================
# Chest X-Ray Dataset Implementation
# ============================================================================

class ChestXRayDataset(Dataset):
    """
    PyTorch Dataset loading images from a prepared split directory.
    Expected directory format:
      root_dir/
        split/
          NORMAL/*.jpeg
          PNEUMONIA/*.jpeg
    """

    def __init__(
        self,
        root_dir: str,
        split: str,
        transform: Optional[Callable] = None,
        class_to_idx: Dict[str, int] = CLASS_TO_IDX,
    ):
        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        self.class_to_idx = class_to_idx

        self.samples: List[Tuple[str, int]] = []
        self._load_samples()

    def _load_samples(self):
        split_path = os.path.join(self.root_dir, self.split)
        if not os.path.exists(split_path):
            raise FileNotFoundError(f"Split directory does not exist: {split_path}")

        valid_exts = {".jpeg", ".jpg", ".png"}
        for cls_name, cls_idx in self.class_to_idx.items():
            cls_dir = os.path.join(split_path, cls_name)
            if not os.path.isdir(cls_dir):
                continue
            for fname in sorted(os.listdir(cls_dir)):
                ext = os.path.splitext(fname)[1].lower()
                if ext in valid_exts:
                    img_path = os.path.join(cls_dir, fname)
                    self.samples.append((img_path, cls_idx))

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        img_path, label = self.samples[idx]
        with Image.open(img_path) as img:
            if self.transform:
                image_tensor = self.transform(img)
            else:
                # Default conversion without transform
                arr = np.array(img.convert("RGB"), dtype=np.float32) / 255.0
                image_tensor = torch.from_numpy(arr).permute(2, 0, 1)

        label_tensor = torch.tensor(label, dtype=torch.long)
        return image_tensor, label_tensor

    def get_labels(self) -> List[int]:
        """Returns all label integers for class weighting and stratification checks."""
        return [label for _, label in self.samples]

    def get_class_counts(self) -> Dict[str, int]:
        """Returns per-class sample counts."""
        counts = {cls_name: 0 for cls_name in self.class_to_idx}
        for _, label in self.samples:
            cls_name = IDX_TO_CLASS[label]
            counts[cls_name] += 1
        return counts


# ============================================================================
# Dynamic Class Weight Calculation (Training Set ONLY)
# ============================================================================

def compute_class_weights(
    train_labels: List[int],
    num_classes: int = 2,
    device: Optional[torch.device] = None,
) -> torch.Tensor:
    """
    Calculates balanced class weights strictly from training labels.
    Formula:
        weight[c] = total_samples / (num_classes * count[c])
    
    Verifies that class weights are non-zero and correctly indexed:
      Index 0: NORMAL (minority class -> weight > 1.0)
      Index 1: PNEUMONIA (majority class -> weight < 1.0)
    
    Args:
        train_labels: List of integer class labels from the training dataset only.
        num_classes: Number of distinct classes (default: 2).
        device: Target compute device for the resulting tensor.
        
    Returns:
        torch.Tensor of shape (num_classes,) containing normalized class weights.
    """
    total_samples = len(train_labels)
    if total_samples == 0:
        raise ValueError("Cannot calculate class weights from an empty label set.")

    counts = np.bincount(train_labels, minlength=num_classes)
    for c, count in enumerate(counts):
        if count == 0:
            raise ValueError(f"Class index {c} has zero training samples; cannot compute weights.")

    # Inverse frequency weighting
    weights = total_samples / (num_classes * counts.astype(np.float32))
    weight_tensor = torch.tensor(weights, dtype=torch.float32)

    if device is not None:
        weight_tensor = weight_tensor.to(device)

    return weight_tensor


# ============================================================================
# DataLoader Factory Helper
# ============================================================================

def create_data_loaders(
    prepared_root: str,
    batch_size: int = 32,
    image_size: int = 224,
    num_workers: int = 0,
    pin_memory: Optional[bool] = None,
    model_type: str = "resnet18",
    cxformer_model_dir: Optional[str] = None,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Constructs train, validation, and test DataLoaders.

    Args:
        prepared_root: Path to prepared dataset containing train/, val/, test/.
        batch_size: Mini-batch size.
        image_size: Target image resolution (used for standard CNN / ResNet-18, default: 224).
        num_workers: Number of DataLoader subprocesses (0 recommended for Windows).
        pin_memory: Whether to pin memory for CUDA transfer (auto-detected if None).
        model_type: Model family architecture ('resnet18', 'custom_cnn', or 'cxformer').
        cxformer_model_dir: Optional explicit path to CXformer model directory.

    Returns:
        (train_loader, val_loader, test_loader)
    """
    if pin_memory is None:
        pin_memory = torch.cuda.is_available()

    is_cxformer = model_type.lower() in ("cxformer", "cxformer_small", "cxformer-small")

    if is_cxformer:
        # Load official CXformer processor once and share across splits
        cx_processor = get_cxformer_processor(cxformer_model_dir)
        train_transform = CXformerTransform(processor=cx_processor)
        eval_transform = CXformerTransform(processor=cx_processor)
    else:
        train_transform = get_transforms(image_size=image_size, is_training=True)
        eval_transform = get_transforms(image_size=image_size, is_training=False)

    train_dataset = ChestXRayDataset(root_dir=prepared_root, split="train", transform=train_transform)
    val_dataset = ChestXRayDataset(root_dir=prepared_root, split="val", transform=eval_transform)
    test_dataset = ChestXRayDataset(root_dir=prepared_root, split="test", transform=eval_transform)

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=False,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=False,
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=False,
    )

    return train_loader, val_loader, test_loader


def create_cxformer_data_loaders(
    prepared_root: str,
    batch_size: int = 16,
    cxformer_model_dir: Optional[str] = None,
    num_workers: int = 0,
    pin_memory: Optional[bool] = None,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Convenience factory to construct DataLoaders specifically configured
    with the official CXformer-Small 518x518 preprocessing pipeline.
    """
    return create_data_loaders(
        prepared_root=prepared_root,
        batch_size=batch_size,
        image_size=518,
        num_workers=num_workers,
        pin_memory=pin_memory,
        model_type="cxformer",
        cxformer_model_dir=cxformer_model_dir,
    )
