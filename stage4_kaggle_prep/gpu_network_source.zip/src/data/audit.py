"""
Dataset Audit Module for Chest X-Ray Images (Pneumonia).

Performs comprehensive pre-training data integrity checks:
1. Validates directory structure across splits and classes.
2. Identifies corrupt or unreadable image files.
3. Counts images by split, class, and etiology (bacterial vs viral).
4. Inspects image dimensions and color channel modes.
5. Computes file hashes to detect intra-split duplicates and cross-split leakage.
6. Flags operating system artifacts (__MACOSX, .DS_Store) without altering dataset files.
7. Exports a structured audit report for review.
"""

import hashlib
import json
import os
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

from PIL import Image


class DatasetAuditor:
    """
    Audits an image classification dataset on disk.
    Compatible with Windows local paths and Kaggle notebook Linux paths.
    """

    def __init__(
        self,
        dataset_root: str,
        splits: Optional[List[str]] = None,
        classes: Optional[List[str]] = None,
        supported_extensions: Optional[List[str]] = None,
        hash_algo: str = "md5",
    ):
        self.dataset_root = Path(dataset_root).resolve()
        self.splits = splits or ["train", "val", "test"]
        self.classes = classes or ["NORMAL", "PNEUMONIA"]
        self.supported_extensions = set(
            ext.lower() for ext in (supported_extensions or [".jpeg", ".jpg", ".png"])
        )
        self.hash_algo = hash_algo.lower()

    def _resolve_split_root(self) -> Path:
        """
        Locates the directory containing the split folders (train, val, test).
        Handles nested extraction structures gracefully.
        """
        if not self.dataset_root.exists():
            raise FileNotFoundError(f"Dataset root does not exist: {self.dataset_root}")

        # Check if splits exist directly under dataset_root
        direct_splits = [s for s in self.splits if (self.dataset_root / s).is_dir()]
        if len(direct_splits) >= 2:
            return self.dataset_root

        # Check immediate subdirectories (e.g., chest_xray/)
        for child in self.dataset_root.iterdir():
            if child.is_dir() and child.name not in ("__MACOSX", ".git"):
                child_splits = [s for s in self.splits if (child / s).is_dir()]
                if len(child_splits) >= 2:
                    return child

        return self.dataset_root

    def _compute_file_hash(self, file_path: Path) -> str:
        """Computes cryptographic hash of a file in 64KB chunks."""
        hasher = hashlib.md5() if self.hash_algo == "md5" else hashlib.sha256()
        with open(file_path, "rb") as f:
            while chunk := f.read(65536):
                hasher.update(chunk)
        return hasher.hexdigest()

    def _verify_image(self, file_path: Path) -> Tuple[bool, Optional[str], Optional[Tuple[int, int]], Optional[str]]:
        """
        Opens and verifies image integrity.
        Returns: (is_valid, error_message, (width, height), color_mode)
        """
        try:
            with Image.open(file_path) as img:
                img.verify()
            # Re-open to read dimensions and mode safely after verify
            with Image.open(file_path) as img:
                size = img.size
                mode = img.mode
            return True, None, size, mode
        except Exception as e:
            return False, str(e), None, None

    def scan_artifacts(self, base_dir: Path) -> Dict[str, Any]:
        """Detects OS metadata artifacts (__MACOSX, .DS_Store, ._*) without touching them."""
        artifacts = {
            "macosx_dir_found": False,
            "ds_store_count": 0,
            "apple_double_files_count": 0,
            "details": [],
        }

        for root, dirs, files in os.walk(base_dir):
            if "__MACOSX" in dirs or "__MACOSX" in root:
                artifacts["macosx_dir_found"] = True

            for f in files:
                if f == ".DS_Store":
                    artifacts["ds_store_count"] += 1
                elif f.startswith("._"):
                    artifacts["apple_double_files_count"] += 1

        if artifacts["macosx_dir_found"]:
            artifacts["details"].append(
                "Detected '__MACOSX' metadata folder. Ensure standard PyTorch loaders point directly to clean split folders."
            )
        if artifacts["ds_store_count"] > 0:
            artifacts["details"].append(
                f"Detected {artifacts['ds_store_count']} '.DS_Store' file(s) across folders."
            )
        if artifacts["apple_double_files_count"] > 0:
            artifacts["details"].append(
                f"Detected {artifacts['apple_double_files_count']} AppleDouble ('._*') metadata files."
            )

        return artifacts

    def run_audit(self, verbose: bool = True) -> Dict[str, Any]:
        """
        Executes full dataset audit.
        """
        start_time = time.time()
        resolved_root = self._resolve_split_root()

        if verbose:
            print(f"\nTarget Dataset Directory: {resolved_root}")
            print(f"Hashing Algorithm        : {self.hash_algo.upper()}")
            print("-" * 65)

        artifacts = self.scan_artifacts(resolved_root)

        split_stats = {}
        all_hashes = defaultdict(list)
        unreadable_images = []
        resolution_stats = {"min_size": None, "max_size": None, "modes": defaultdict(int)}

        total_scanned_files = 0

        for split in self.splits:
            split_dir = resolved_root / split
            if not split_dir.is_dir():
                split_stats[split] = {"status": "MISSING", "total_images": 0}
                continue

            split_info = {
                "status": "PRESENT",
                "classes": {},
                "total_images": 0,
                "bacteria_count": 0,
                "virus_count": 0,
            }

            for cls in self.classes:
                cls_dir = split_dir / cls
                if not cls_dir.is_dir():
                    split_info["classes"][cls] = {"status": "MISSING", "count": 0}
                    continue

                cls_files = [
                    p for p in cls_dir.iterdir()
                    if p.is_file() and p.suffix.lower() in self.supported_extensions
                ]

                valid_count = 0
                cls_bacteria = 0
                cls_virus = 0

                for img_path in cls_files:
                    total_scanned_files += 1
                    fname = img_path.name.lower()

                    if "bacteria" in fname:
                        cls_bacteria += 1
                    elif "virus" in fname:
                        cls_virus += 1

                    # Verify image
                    is_valid, err_msg, size, mode = self._verify_image(img_path)
                    if not is_valid:
                        unreadable_images.append({
                            "path": str(img_path),
                            "split": split,
                            "class": cls,
                            "error": err_msg,
                        })
                        continue

                    valid_count += 1
                    if mode:
                        resolution_stats["modes"][mode] += 1
                    if size:
                        w, h = size
                        if resolution_stats["min_size"] is None:
                            resolution_stats["min_size"] = [w, h]
                            resolution_stats["max_size"] = [w, h]
                        else:
                            resolution_stats["min_size"][0] = min(resolution_stats["min_size"][0], w)
                            resolution_stats["min_size"][1] = min(resolution_stats["min_size"][1], h)
                            resolution_stats["max_size"][0] = max(resolution_stats["max_size"][0], w)
                            resolution_stats["max_size"][1] = max(resolution_stats["max_size"][1], h)

                    # Compute hash for duplicate tracking
                    file_hash = self._compute_file_hash(img_path)
                    all_hashes[file_hash].append({
                        "path": str(img_path),
                        "name": img_path.name,
                        "split": split,
                        "class": cls,
                    })

                split_info["classes"][cls] = {
                    "status": "PRESENT",
                    "valid_images": valid_count,
                    "bacteria": cls_bacteria,
                    "virus": cls_virus,
                }
                split_info["total_images"] += valid_count
                split_info["bacteria_count"] += cls_bacteria
                split_info["virus_count"] += cls_virus

                if verbose:
                    print(f"[{split.upper():5s}] {cls:9s} : {valid_count:5d} images verified "
                          f"(Bacteria: {cls_bacteria}, Virus: {cls_virus})")

            split_stats[split] = split_info

        # Analyze duplicates
        intra_split_duplicates = []
        cross_split_leakages = []
        cross_class_conflicts = []

        for h, records in all_hashes.items():
            if len(records) > 1:
                splits_seen = set(r["split"] for r in records)
                classes_seen = set(r["class"] for r in records)

                if len(splits_seen) > 1:
                    cross_split_leakages.append({
                        "hash": h,
                        "splits": sorted(list(splits_seen)),
                        "classes": sorted(list(classes_seen)),
                        "count": len(records),
                        "occurrences": records,
                    })
                else:
                    split_name = records[0]["split"]
                    if len(classes_seen) > 1:
                        cross_class_conflicts.append({
                            "hash": h,
                            "split": split_name,
                            "conflicting_classes": sorted(list(classes_seen)),
                            "count": len(records),
                            "occurrences": records,
                        })
                    else:
                        intra_split_duplicates.append({
                            "hash": h,
                            "split": split_name,
                            "class": records[0]["class"],
                            "count": len(records),
                            "occurrences": records,
                        })

        elapsed_time = round(time.time() - start_time, 2)

        # Per-split duplicate counts
        dups_by_split = {
            s: len([d for d in intra_split_duplicates if d["split"] == s])
            for s in self.splits
        }

        # Assemble summary report
        report = {
            "audit_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "dataset_root": str(self.dataset_root),
            "resolved_split_root": str(resolved_root),
            "total_files_scanned": total_scanned_files,
            "elapsed_seconds": elapsed_time,
            "split_statistics": split_stats,
            "resolution_summary": {
                "min_dimensions_wh": resolution_stats["min_size"],
                "max_dimensions_wh": resolution_stats["max_size"],
                "color_modes": dict(resolution_stats["modes"]),
            },
            "unreadable_corrupt_images": {
                "count": len(unreadable_images),
                "items": unreadable_images,
            },
            "duplicate_analysis": {
                "intra_split_duplicate_groups": len(intra_split_duplicates),
                "intra_split_duplicates_by_split": dups_by_split,
                "intra_split_duplicates": intra_split_duplicates,
                "cross_class_conflict_groups": len(cross_class_conflicts),
                "cross_class_conflicts": cross_class_conflicts,
                "cross_split_leakage_groups": len(cross_split_leakages),
                "cross_split_leakages": cross_split_leakages,
            },
            "filesystem_artifacts": artifacts,
            "overall_status": "PASS" if (len(unreadable_images) == 0 and len(cross_class_conflicts) == 0) else "WARNING_ISSUES_FOUND",
        }

        return report

    def save_report(self, report: Dict[str, Any], output_path: str) -> Path:
        """Saves audit results to JSON."""
        out_p = Path(output_path).resolve()
        out_p.parent.mkdir(parents=True, exist_ok=True)
        with open(out_p, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        return out_p


def run_dataset_audit(
    dataset_dir: str,
    output_report_path: Optional[str] = None,
    hash_algo: str = "md5",
    verbose: bool = True,
) -> Dict[str, Any]:
    """
    Convenience function to execute audit and save report.
    """
    auditor = DatasetAuditor(dataset_root=dataset_dir, hash_algo=hash_algo)
    report = auditor.run_audit(verbose=verbose)
    if output_report_path:
        saved_file = auditor.save_report(report, output_report_path)
        if verbose:
            print(f"\nAudit report saved to: {saved_file}")
    return report
