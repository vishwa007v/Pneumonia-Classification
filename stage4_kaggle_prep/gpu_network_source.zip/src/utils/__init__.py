"""
Hardware and compute device utilities.
"""

from .device import get_compute_device, print_device_info

__all__ = ["get_compute_device", "print_device_info"]
